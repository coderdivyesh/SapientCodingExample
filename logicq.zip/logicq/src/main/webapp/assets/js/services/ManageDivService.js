
(function () {
	'use strict';
angular.module('crmlogicq').factory('ManageDivService', [ function (){
	
	return {
	
	
		
		
		
	}
}]);
}());