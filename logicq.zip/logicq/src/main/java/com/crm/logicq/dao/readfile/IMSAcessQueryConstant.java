package com.crm.logicq.dao.readfile;

public interface IMSAcessQueryConstant {

	public static final String SELECT_QUERY="SELECT CARDID,INTIME,OUTTIME,INPUTDATE FROM CARDINFO";
}
