package com.crm.logicq.dao.user;

public interface UserConstant {

	public static final String GET_ATTENDANCE_DETAILS_QRY = "from AttendanceDetails attd where ";

}
