package com.crm.logicq.service.alert.impl.sms;

import com.crm.logicq.service.alert.IAlertImplService;

public interface ISMSService extends IAlertImplService{

}
