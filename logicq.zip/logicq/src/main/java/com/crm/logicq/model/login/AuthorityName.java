package com.crm.logicq.model.login;

public enum AuthorityName {
    ROLE_USER, ROLE_ADMIN
}