package com.crm.logicq.service.alert;

import com.crm.logicq.ui.alert.AlertDetailsInputVO;

public interface IAlertService {
	
	public String buildAlert(AlertDetailsInputVO alertDetailsVO);

}
