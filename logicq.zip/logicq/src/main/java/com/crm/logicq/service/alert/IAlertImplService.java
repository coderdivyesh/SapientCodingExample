package com.crm.logicq.service.alert;

public interface IAlertImplService {

}
