package com.crm.logicq.service.readfile;

public interface ISchedulerService {
	
	public void readAccessFile() throws Exception;
	
	public void performTask();

}
