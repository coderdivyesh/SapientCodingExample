package com.crm.logicq.model.login;

public interface LoginConstant {

	  public static final String EMAIL = "email";
	  public static final String PHONENUMBER = "phonnumber";
	  public static final String PASSWORD = "password";
	  
	  

}
