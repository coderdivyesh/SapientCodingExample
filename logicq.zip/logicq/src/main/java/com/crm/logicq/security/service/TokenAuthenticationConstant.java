package com.crm.logicq.security.service;

public interface TokenAuthenticationConstant {
	
	  public static final String AUTH_HEADER_NAME = "AUTH-TOKEN";

}
