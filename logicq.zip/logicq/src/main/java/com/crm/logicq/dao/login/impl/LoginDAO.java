package com.crm.logicq.dao.login.impl;

import org.springframework.stereotype.Repository;

import com.crm.logicq.common.AbstractDAO;
import com.crm.logicq.dao.login.ILoginDAO;
import com.crm.logicq.model.login.Login;

@Repository
public class LoginDAO extends AbstractDAO<Login> implements ILoginDAO {

	

	
	

}
