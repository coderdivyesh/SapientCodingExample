package com.crm.logicq.dao.login;

/**
 * Login DAO Interface
 * 
 * @author SudhanshuL
 * @since 13 Dec 2015
 * @version 1.0.0
 */
public interface ILoginDAO {

	
}
