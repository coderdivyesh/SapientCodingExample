package com.crm.logicq.service.login.impl;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.crm.logicq.service.login.IloginService;

@Service
@Transactional
public class LoginService implements IloginService {




}
