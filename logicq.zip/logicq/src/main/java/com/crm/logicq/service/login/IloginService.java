package com.crm.logicq.service.login;

public interface IloginService {

}
