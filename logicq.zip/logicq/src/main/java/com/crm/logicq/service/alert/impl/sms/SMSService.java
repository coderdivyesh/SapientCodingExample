package com.crm.logicq.service.alert.impl.sms;

import org.springframework.stereotype.Service;

@Service
public class SMSService implements ISMSService {

}
