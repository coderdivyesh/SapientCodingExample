package com.lock.example;

public class Test {
    public  void testMethod1() {
        System.out.println("Thread:" + Thread.currentThread().getName());
		  //Thread.sleep(2000);
    }
    public synchronized void testMethod2() {
        System.out.println("Thread:" + Thread.currentThread().getName());
		    //Thread.sleep(2000); 
    }
    public static void main (String[] args) throws InterruptedException {
        final Test t = new Test();
        Thread t1 = new Thread() { public void run() { t.testMethod1(); } };
        Thread t2 = new Thread() { public void run() { t.testMethod1(); } };
        t1.start();
        Thread.sleep(1000);
        t2.start();
        //Thread.sleep(500);
        //System.out.println(t1.getState());
    }
}

