package com.divyesh.setterandgetterexample;

public class Test {

	public static void main(String[] args) {
		Person p=new Person();
		p.i=10;
		System.out.println("First Person Object = "+ p.i);
		
		p.i=20;
		System.out.println("Second Person Object = "+ p.i);

	}

}
