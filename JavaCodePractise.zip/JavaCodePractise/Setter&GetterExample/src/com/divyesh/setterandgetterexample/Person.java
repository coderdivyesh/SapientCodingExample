package com.divyesh.setterandgetterexample;

public class Person {
	int i;
	public Person() {
	
	}


}
