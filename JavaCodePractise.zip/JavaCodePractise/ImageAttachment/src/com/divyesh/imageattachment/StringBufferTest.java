package com.divyesh.imageattachment;

public class StringBufferTest {

	public static void main(String[] args) {
		StringBuffer sb=new StringBuffer("divyesh");
		update(sb);
		System.out.println(sb);
	}
	
	public static void update(StringBuffer sb)
	{
		sb.append("dwivedi");
	}
}
