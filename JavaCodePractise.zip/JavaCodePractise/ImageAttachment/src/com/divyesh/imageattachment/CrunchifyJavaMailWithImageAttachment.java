package com.divyesh.imageattachment;

import java.io.FileNotFoundException;
import java.io.InputStream;
import java.util.Date;
import java.util.Properties;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.mail.BodyPart;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

public class CrunchifyJavaMailWithImageAttachment extends EmailUtil
{

	public static void main(String args[]) throws AddressException, MessagingException {

		InputStream inputStream;
		MimeBodyPart textBodyPart = null;
		try {
			Properties prop = new Properties();
			String propFileName = "Mail.properties";
			inputStream = ClassLoader.class.getResourceAsStream(propFileName);
			if (inputStream != null) {
				prop.load(inputStream);
			} else {
				throw new FileNotFoundException("property file '" + propFileName + "' not found in the classpath");
			}
			String mailServer = prop.getProperty("mailServer");
			Properties properties = System.getProperties();
			properties.setProperty("mail.smtp.host", mailServer);
			Session session = Session.getDefaultInstance(properties, null);
			generateAndSendEmail(
	                session,
	                prop,
	                "Crunchify's JavaMail API example with Image Attachment",
	                "Greetings, <br><br>Test email by Crunchify.com JavaMail API example. Please find here attached Image."
	                        + "<br><br> Regards, <br>Crunchify Admin");


		} catch (Exception ex) {
			System.out.println("Mail not sent ..." + ex);
		}

	}
	
	
	public static void generateAndSendEmail(Session session, Properties prop, String subject,
            String body) {
        try {
            MimeMessage crunchifyMessage = new MimeMessage(session);
            crunchifyMessage.addHeader("Content-type", "text/HTML; charset=UTF-8");
            crunchifyMessage.addHeader("format", "flowed");
            crunchifyMessage.addHeader("Content-Transfer-Encoding", "8bit");
            InternetAddress iaSender = new InternetAddress(prop.getProperty("from"));
    		InternetAddress iaRecipient = new InternetAddress(prop.getProperty("to"));
            crunchifyMessage.setSender(iaSender);
            crunchifyMessage.setSubject(subject, "UTF-8");
            crunchifyMessage.setSentDate(new Date());
            crunchifyMessage.setRecipient(Message.RecipientType.TO, iaRecipient);
            // Create the message body part
            BodyPart messageBodyPart = new MimeBodyPart();
            messageBodyPart.setContent(body, "text/html");
 
            // Create a multipart message for attachment
            Multipart multipart = new MimeMultipart();
 
            // Set text message part
            multipart.addBodyPart(messageBodyPart);
 
            messageBodyPart = new MimeBodyPart();
 
            // Valid file location
            String filename = "C:/Users/611022675/Desktop/btpoc-.png";
            DataSource source = new FileDataSource(filename);
            messageBodyPart.setDataHandler(new DataHandler(source));
            messageBodyPart.setFileName(filename);
            // Trick is to add the content-id header here
            messageBodyPart.setHeader("Content-ID", "image_id");
            multipart.addBodyPart(messageBodyPart);
 
            System.out.println("\n4th ===> third part for displaying image in the email body..");
            messageBodyPart = new MimeBodyPart();
            messageBodyPart.setContent("<br><h3>Find below attached image</h3>"
                    + "<img src='cid:image_id'>", "text/html");
            multipart.addBodyPart(messageBodyPart);
            crunchifyMessage.setContent(multipart);
 
            System.out.println("\n5th ===> Finally Send message..");
 
            // Finally Send message
            Transport.send(crunchifyMessage);
 
            System.out
                    .println("\n6th ===> Email Sent Successfully With Image Attachment. Check your email now..");
            System.out.println("\n7th ===> generateAndSendEmail() ends..");
 
        } catch (MessagingException e) {
            e.printStackTrace();
        }

}
}
    	
     
  
