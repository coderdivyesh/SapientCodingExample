package com.divyesh.imageattachment;

public class EmailUtil {

	public static void sendEmail()
	{
		
	}
}
