package com.divyesh.abstractcons;

public abstract class Person {

	abstract void display();
	Person(int i)
	{
		System.out.println("This is abstract class" + i );
	}
}
