package com.divyesh.abstractcons;

public class Child extends Person{

	public Child()
	{
		super(10);
	}
	void display() {
		System.out.println("Inside Child Class");
	}
}
