package com.divyesh.abstractcons;

public class Test {

	public static void main(String[] args) {
		Child c=new Child();
		c.display();

	}

}
