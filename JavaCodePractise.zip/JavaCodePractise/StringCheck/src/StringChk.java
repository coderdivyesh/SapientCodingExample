
public class StringChk {
      public static void main(String[] args) {
            final String a = "a"; // Store it into Heap 
            final String b = "b"; // Store it into Heap 
           String ab = "ab"; // Store it into String Constant Pool
           
          /* When a+b is called, internally and intern method ( for FINAL String ) is called and the string a+b after concatination is stored
           into  String Constant Pool where ab already exist*/
           
           System.out.println(a+b == ab);  // TRUE
 
           String a2 = "a";
           String b2 = "b";                  
           System.out.println(a2+b2 == ab); 
            
      }
       
 
} 

